﻿using ACGRT;

public class Scene {
    public List<IHitable> Items = new();
    public int WIDTH => Output.Width;
    public int HEIGHT => Output.Height;
    
    public RawImage Output = null;
    public void AddItem(IHitable item) {
        Items.Add(item);
    }
    public bool Hit(Ray r, ref float tMin, ref float tMax, out HitRecord record) {
        // traverse all the item the scene hold
        HitRecord tempRec = new();
        record = tempRec;
        bool hitAny = false;
        float currentCloset = tMax;

        foreach (var item in Items) {
            if (item.Hit(r, ref tMin, ref currentCloset, out tempRec)) {
                hitAny = true;
                currentCloset = tempRec.t;
                record = tempRec;
            }
        }
        return hitAny;
    }
};
