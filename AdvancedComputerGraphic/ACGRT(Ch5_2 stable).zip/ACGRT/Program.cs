﻿using System.Numerics;
using ACGRT;

public class Program {
    // Sky
    private static Vector3 topColor = Vector3.One * 255;
    private static Vector3 bottomColor = new Vector3(0.5f, 0.7f, 1.0f) * 255;

    public static Vector3 RayCast(Ray ray, Scene scene) {
        HitRecord rec;
        float min = 0;
        float max = float.MaxValue;
        if (scene.Hit(ray, ref min, ref max, out rec)) {
            return 0.5f * (Vector3.Normalize(rec.normal) + Vector3.One ) * 255;
        }
        else {

            // not hit so render sky
            Vector3 uniDirection = Vector3.Normalize(ray.direction);
            float t = 0.5f * (uniDirection.Y + 1.0f);
            return Vector3.Lerp(topColor, bottomColor, t);
        }
    }
    // ----------------------------------
    private static void Main(string[] args) {

        int WIDTH = 1280;
        int HEIGHT = 720;
        RawImage raw = new RawImage(WIDTH, HEIGHT);

        Scene scene = new Scene();
        Camera eye = new Camera();
        eye.SetOrigin(Vector3.Zero);
        eye.Configure(
             new Vector3(-2.0f, -1.0f, -1.0f),  // lowerleftcorner
             new Vector3(4.0f, 0.0f, 0.0f),     // horizontal
             new Vector3(0.0f, 2.0f, 0.0f)      // vertical
        );
        scene.AddItem(new Sphere(new Vector3(0, 0, -1), 0.5f));
        scene.AddItem(new Sphere(new Vector3(0, -100.5f, -1), 100));

        for (int j = 0; j < HEIGHT; ++j) {
            for (int i = 0; i < WIDTH; ++i) {
                float u = i / (float)(WIDTH);
                float v = j / (float)(HEIGHT);
                Ray r = eye.GetRay(u, v); 
                Vector3 color = RayCast(r,scene);
                raw.SetPixel(i, j, color);
            }
        }
        
        raw.FinishEdit();
        raw.FlipY();
        raw.SaveFile("chapter4.png");
    }
}

/*
 Default Scene
int WIDTH = 1280;
int HEIGHT = 720;
RawImage raw = new RawImage(WIDTH, HEIGHT);

Scene scene = new Scene();
Camera eye = new Camera();
eye.SetOrigin(Vector3.Zero);
eye.Configure(
        new Vector3(-2.0f, -1.0f, -1.0f),  // lowerleftcorner
        new Vector3(4.0f, 0.0f, 0.0f),     // horizontal
        new Vector3(0.0f, 2.0f, 0.0f)      // vertical
);
scene.AddItem(new Sphere(new Vector3(0, 0, -1), 0.5f));
scene.AddItem(new Sphere(new Vector3(0, -100.5f, -1), 100));
 
 */