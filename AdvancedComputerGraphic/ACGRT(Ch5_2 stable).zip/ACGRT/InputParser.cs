﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ACGRT; 
public static class InputParser {
    public static (Camera, Scene) Parse(string filename) {
        
        Scene scene = new Scene();
        Camera camera = new Camera();
        Vector3 UL = new(), UR = new(), LL = new(), LR = new();
        // Parse the input lines
        string[] lines = File.ReadAllLines(filename);
        foreach (string line in lines) {
            string[] tokens = line.Split(' ');
            if (tokens.Length < 2) {
                Console.WriteLine("Invalid input line: " + line);
                continue;
            }
            string type = tokens[0];

            switch (type) {
               
                case "S":
                    Sphere sphere = new Sphere(
                        new Vector3(
                            float.Parse(tokens[1]),
                            float.Parse(tokens[2]),
                            float.Parse(tokens[3])
                        ),
                        float.Parse(tokens[4])
                    );
                    Console.WriteLine($"S {sphere.origin}, {sphere.radius}");
                    scene.Items.Add(sphere);
                    break;
                case "T":
                    Triangle triangle = new Triangle(
                        new Vector3(float.Parse(tokens[1]), float.Parse(tokens[2]), float.Parse(tokens[3])),
                        new Vector3(float.Parse(tokens[4]), float.Parse(tokens[5]), float.Parse(tokens[6])),
                        new Vector3(float.Parse(tokens[7]), float.Parse(tokens[8]), float.Parse(tokens[9]))
                    );
                    Console.WriteLine($"T {triangle.position1}, {triangle.position2}, {triangle.position3}");
                    scene.Items.Add(triangle);
                    break;
                case "E":
                    camera.SetOrigin(new Vector3(float.Parse(tokens[1]), float.Parse(tokens[2]), float.Parse(tokens[3])));
                    Console.WriteLine($"E {camera.origin}");
                    break;
                case "O":
                    UL = new Vector3(float.Parse(tokens[1]), float.Parse(tokens[2]), float.Parse(tokens[3]));
                    UR = new Vector3(float.Parse(tokens[4]), float.Parse(tokens[5]), float.Parse(tokens[6]));
                    LL = new Vector3(float.Parse(tokens[7]), float.Parse(tokens[8]), float.Parse(tokens[9]));
                    LR = new Vector3(float.Parse(tokens[10]), float.Parse(tokens[11]), float.Parse(tokens[12]));
                    camera.Configure(UL, UR, LL, LR);
                    Console.WriteLine($"O {UL}, {UR}, {LL}, {LR}");
                    break;
                case "R":
                    scene.Output = new RawImage(scene.WIDTH, scene.HEIGHT);
                    Console.WriteLine($"R {scene.WIDTH} x {scene.HEIGHT}");
                    break;
                default:
                    Console.WriteLine("Unknown input type: " + type);
                    break;
            }
            
        }
       
        // add viewport to raycam
        Console.WriteLine("Parse Finish ...");
        return (camera, scene);
    }
}
